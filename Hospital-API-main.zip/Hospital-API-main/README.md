# Hospital-API
I have to design an API for the doctors of a Hospital which has been allocated by the govt for testing with the patients
